# Tax Harvest Tracker Deployment Steps

This app is a static web application. It has one main file:

- `index.html`

It can be hosted for free on static hosting platforms.

## Best Free Option: Netlify Drop

Use this if you want the fastest free live URL and do not want to learn Git yet.

1. Open https://app.netlify.com/drop
2. Sign up or log in with a free Netlify account.
3. Drag the full `tax-harvest-app` folder onto the upload area.
4. Netlify will publish it and give you a free URL like:
   `https://your-site-name.netlify.app`
5. In Netlify site settings, rename the site if you want a cleaner free URL.

## Best Learning Option: GitHub Pages

Use this if you want to learn the normal developer workflow.

1. Create a free GitHub account.
2. Create a new public repository.
3. Upload everything inside this folder.
4. Make sure the main file is named `index.html`.
5. Go to repository Settings > Pages.
6. Choose Deploy from a branch.
7. Select your main branch and the root folder.
8. GitHub will publish the site at a free URL like:
   `https://your-username.github.io/repository-name/`

## About Free Domains

Free hosting URLs are reliable:

- `your-name.github.io`
- `your-site.netlify.app`
- `your-project.pages.dev`

Fully custom domains like `yourname.com` usually require buying a domain. If you buy one later, you can connect it to GitHub Pages, Netlify, or Cloudflare Pages.

## Important Data Note

This app saves data in `localStorage`, which means data is saved inside the visitor's browser. It is not synced across devices and is not stored on a server.
